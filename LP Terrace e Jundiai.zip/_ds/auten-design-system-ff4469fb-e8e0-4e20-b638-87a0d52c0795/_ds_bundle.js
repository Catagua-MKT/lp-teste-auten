/* @ds-bundle: {"format":3,"namespace":"AutenDesignSystem_ff4469","components":[{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"PropertyCard","sourcePath":"components/content/PropertyCard.jsx"},{"name":"Stat","sourcePath":"components/content/Stat.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"}],"sourceHashes":{"components/content/Card.jsx":"1fcf3d2a3570","components/content/PropertyCard.jsx":"37b50dccdfea","components/content/Stat.jsx":"046271b28df2","components/core/Badge.jsx":"bf307f333d34","components/core/Button.jsx":"c90e53401bee","components/core/IconButton.jsx":"baae657db61c","components/forms/Checkbox.jsx":"78c98fc920cf","components/forms/Input.jsx":"6f6c4b060d64","components/forms/Select.jsx":"78a31a7f41f0","ui_kits/website/DetailScreen.jsx":"d38416a0b2e8","ui_kits/website/ExtraScreens.jsx":"89c44e9c38c0","ui_kits/website/Footer.jsx":"7a36fb4bd94f","ui_kits/website/Header.jsx":"8781c21ceed3","ui_kits/website/HomeScreen.jsx":"c1eb126fcef3","ui_kits/website/ListingScreen.jsx":"d0eec25e6885","ui_kits/website/data.js":"8fc533bd37de"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AutenDesignSystem_ff4469 = window.AutenDesignSystem_ff4469 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten Card — a calm surface container.
 * Hairline ring on light surfaces; optional eyebrow + title header.
 */
function Card({
  children,
  eyebrow,
  title,
  tone = 'paper',
  interactive = false,
  padding = 'comfy',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const tones = {
    paper: {
      background: 'var(--surface-card)',
      color: 'var(--text-body)',
      ring: 'var(--ring-card)'
    },
    white: {
      background: 'var(--surface-raised)',
      color: 'var(--text-body)',
      ring: 'var(--ring-card)'
    },
    dark: {
      background: 'var(--surface-dark)',
      color: 'var(--text-on-dark)',
      ring: 'inset 0 0 0 1px var(--line-on-dark)'
    }
  };
  const t = tones[tone] || tones.paper;
  const pads = {
    none: '0',
    snug: 'var(--space-4)',
    comfy: 'var(--space-6)',
    roomy: 'var(--space-7)'
  };
  const base = {
    background: t.background,
    color: t.color,
    borderRadius: 'var(--radius-card)',
    boxShadow: interactive && hover ? 'var(--shadow-md)' : t.ring,
    padding: pads[padding],
    transition: 'box-shadow var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard)',
    transform: interactive && hover ? 'translateY(-2px)' : 'none',
    cursor: interactive ? 'pointer' : 'default'
  };
  const onDark = tone === 'dark';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...base,
      ...style
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest), (eyebrow || title) && /*#__PURE__*/React.createElement("header", {
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      marginBottom: '10px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 1,
      background: 'var(--auten-terracotta)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--text-accent)'
    }
  }, eyebrow)), title && /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      font: 'var(--type-display-s)',
      letterSpacing: 'var(--tracking-display)',
      color: onDark ? 'var(--auten-paper)' : 'var(--text-strong)'
    }
  }, title)), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/content/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten Stat — a large serif figure with a letterspaced caption.
 * Used for credibility numbers (anos de mercado, unidades entregues).
 */
function Stat({
  value,
  label,
  suffix,
  tone = 'light',
  align = 'start',
  style,
  ...rest
}) {
  const onDark = tone === 'dark';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-display-m)',
      letterSpacing: 'var(--tracking-display)',
      color: onDark ? 'var(--auten-paper)' : 'var(--text-strong)',
      lineHeight: 1
    }
  }, value), suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-display-s)',
      color: 'var(--text-accent)',
      lineHeight: 1
    }
  }, suffix)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: onDark ? 'var(--text-on-dark-muted)' : 'var(--text-muted)'
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Stat.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten Badge — a small status / category marker.
 * Quiet by default; `tone` shifts the color treatment.
 */
function Badge({
  children,
  tone = 'neutral',
  variant = 'soft',
  style,
  ...rest
}) {
  const tones = {
    neutral: {
      fg: 'var(--text-muted)',
      bg: 'rgba(38,38,44,0.06)',
      line: 'var(--line-soft)'
    },
    accent: {
      fg: 'var(--auten-terracotta-deep)',
      bg: 'var(--auten-terracotta-tint)',
      line: 'rgba(177,87,50,0.32)'
    },
    slate: {
      fg: 'var(--auten-paper)',
      bg: 'var(--auten-slate)',
      line: 'var(--auten-slate)'
    },
    positive: {
      fg: '#3F5A3A',
      bg: 'rgba(92,122,86,0.16)',
      line: 'rgba(92,122,86,0.4)'
    },
    warning: {
      fg: '#7A5A1F',
      bg: 'rgba(185,138,54,0.18)',
      line: 'rgba(185,138,54,0.4)'
    }
  };
  const t = tones[tone] || tones.neutral;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    padding: '4px 10px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--weight-medium)',
    fontSize: '0.6875rem',
    letterSpacing: 'var(--tracking-wide)',
    textTransform: 'uppercase',
    lineHeight: 1.1,
    borderRadius: 'var(--radius-pill)',
    color: t.fg
  };
  const skins = {
    soft: {
      background: t.bg
    },
    outline: {
      background: 'transparent',
      boxShadow: `inset 0 0 0 1px ${t.line}`
    },
    solid: {
      background: tone === 'accent' ? 'var(--auten-terracotta)' : t.fg,
      color: 'var(--auten-paper)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      ...(skins[variant] || skins.soft),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/content/PropertyCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten PropertyCard — the signature real-estate listing tile.
 * Image with protection gradient, status badge, name, location and specs.
 */
function PropertyCard({
  image,
  name,
  location,
  status,
  statusTone = 'accent',
  price,
  specs = [],
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-raised)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden',
      boxShadow: hover ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
      transition: 'box-shadow var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard)',
      transform: hover ? 'translateY(-3px)' : 'none',
      cursor: onClick ? 'pointer' : 'default',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '4 / 3',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: `url(${image})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      transition: 'transform var(--dur-slow) var(--ease-standard)',
      transform: hover ? 'scale(1.04)' : 'scale(1)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--scrim-image)'
    }
  }), status && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 14,
      left: 14
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: statusTone,
    variant: "solid"
  }, status)), location && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 16,
      bottom: 14,
      font: 'var(--type-caption)',
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      color: 'var(--auten-paper)'
    }
  }, location)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-5) var(--space-5) var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 4px',
      font: 'var(--type-display-s)',
      letterSpacing: 'var(--tracking-display)',
      color: 'var(--text-strong)'
    }
  }, name), price && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      font: 'var(--type-body-s)',
      color: 'var(--text-accent)',
      letterSpacing: 'var(--tracking-wide)'
    }
  }, price), specs.length > 0 && /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: '14px 0 0',
      padding: '14px 0 0',
      borderTop: '1px solid var(--line-hairline)',
      display: 'flex',
      gap: 'var(--space-5)'
    }
  }, specs.map((s, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-heading-s)',
      color: 'var(--text-strong)'
    }
  }, s.value), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, s.label))))));
}
Object.assign(__ds_scope, { PropertyCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/PropertyCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten Button — the brand's primary action.
 * Squared, confident, letterspaced. Terracotta is the only filled accent.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  type = 'button',
  disabled = false,
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 16px',
      fontSize: '0.75rem',
      gap: '8px'
    },
    md: {
      padding: '12px 24px',
      fontSize: '0.8125rem',
      gap: '10px'
    },
    lg: {
      padding: '16px 32px',
      fontSize: '0.875rem',
      gap: '12px'
    }
  };
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: sizes[size].gap,
    width: fullWidth ? '100%' : 'auto',
    padding: sizes[size].padding,
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--weight-semibold)',
    fontSize: sizes[size].fontSize,
    letterSpacing: 'var(--tracking-eyebrow)',
    textTransform: 'uppercase',
    lineHeight: 1,
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard), transform var(--dur-fast) var(--ease-standard)',
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: 'var(--accent)',
      color: 'var(--accent-contrast)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--text-strong)',
      borderColor: 'var(--line-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-accent)'
    },
    onDark: {
      background: 'transparent',
      color: 'var(--text-on-dark)',
      borderColor: 'var(--line-on-dark)'
    }
  };
  const hovers = {
    primary: {
      background: 'var(--accent-hover)'
    },
    secondary: {
      borderColor: 'var(--text-strong)',
      background: 'rgba(38,38,44,0.04)'
    },
    ghost: {
      color: 'var(--accent-press)'
    },
    onDark: {
      background: 'rgba(245,243,240,0.08)',
      borderColor: 'var(--auten-paper)'
    }
  };
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const composed = {
    ...base,
    ...variants[variant],
    ...(hover && !disabled ? hovers[variant] : null),
    ...(active && !disabled ? {
      transform: 'translateY(1px)'
    } : null),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: composed
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten IconButton — a square, quiet control for a single glyph.
 * Pass any SVG / node as children.
 */
function IconButton({
  children,
  variant = 'ghost',
  size = 'md',
  disabled = false,
  ariaLabel,
  onClick,
  style,
  ...rest
}) {
  const dims = {
    sm: 32,
    md: 40,
    lg: 48
  };
  const d = dims[size] || 40;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: d,
    height: d,
    padding: 0,
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    color: 'var(--text-strong)',
    background: 'transparent',
    transition: 'background var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)'
  };
  const variants = {
    ghost: {},
    outline: {
      borderColor: 'var(--line-soft)'
    },
    solid: {
      background: 'var(--accent)',
      color: 'var(--accent-contrast)'
    },
    onDark: {
      color: 'var(--text-on-dark)',
      borderColor: 'var(--line-on-dark)'
    }
  };
  const hovers = {
    ghost: {
      background: 'rgba(38,38,44,0.05)'
    },
    outline: {
      borderColor: 'var(--text-strong)'
    },
    solid: {
      background: 'var(--accent-hover)'
    },
    onDark: {
      background: 'rgba(245,243,240,0.08)'
    }
  };
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": ariaLabel,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...variants[variant],
      ...(hover && !disabled ? hovers[variant] : null),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten Checkbox — squared control with a terracotta checked state.
 */
function Checkbox({
  label,
  checked,
  defaultChecked,
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const on = isControlled ? checked : internal;
  const box = {
    width: 18,
    height: 18,
    flexShrink: 0,
    borderRadius: 'var(--radius-xs)',
    border: `1.5px solid ${on ? 'var(--accent)' : 'var(--line-strong)'}`,
    background: on ? 'var(--accent)' : 'transparent',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'background var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)'
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: on,
    disabled: disabled,
    onChange: e => {
      if (!isControlled) setInternal(e.target.checked);
      onChange && onChange(e);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: box
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--accent-contrast)",
    strokeWidth: "3",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6L9 17l-5-5"
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-m)',
      color: 'var(--text-body)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten Input — a quiet, architectural text field.
 * Hairline underline by default; box variant for forms.
 */
function Input({
  label,
  hint,
  error,
  variant = 'line',
  type = 'text',
  value,
  defaultValue,
  placeholder,
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const wrap = {
    display: 'flex',
    flexDirection: 'column',
    gap: '7px',
    width: '100%'
  };
  const labelStyle = {
    font: 'var(--type-eyebrow)',
    letterSpacing: 'var(--tracking-eyebrow)',
    textTransform: 'uppercase',
    color: error ? 'var(--status-critical)' : 'var(--text-muted)'
  };
  const fieldBase = {
    font: 'var(--type-body-m)',
    color: 'var(--text-strong)',
    background: 'transparent',
    width: '100%',
    outline: 'none',
    transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
    opacity: disabled ? 0.5 : 1
  };
  const skins = {
    line: {
      border: 'none',
      borderBottom: `1.5px solid ${error ? 'var(--status-critical)' : focus ? 'var(--accent)' : 'var(--line-soft)'}`,
      borderRadius: 0,
      padding: '8px 2px'
    },
    box: {
      border: `1px solid ${error ? 'var(--status-critical)' : focus ? 'var(--accent)' : 'var(--line-soft)'}`,
      borderRadius: 'var(--radius-sm)',
      padding: '12px 14px',
      boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      background: 'var(--surface-raised)'
    }
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      ...wrap,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: labelStyle
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...fieldBase,
      ...skins[variant]
    }
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: error ? 'var(--status-critical)' : 'var(--text-faint)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Auten Select — native select styled to match Input, with a chevron.
 */
function Select({
  label,
  hint,
  error,
  variant = 'box',
  value,
  defaultValue,
  disabled = false,
  onChange,
  children,
  options,
  placeholder,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const wrap = {
    display: 'flex',
    flexDirection: 'column',
    gap: '7px',
    width: '100%'
  };
  const labelStyle = {
    font: 'var(--type-eyebrow)',
    letterSpacing: 'var(--tracking-eyebrow)',
    textTransform: 'uppercase',
    color: error ? 'var(--status-critical)' : 'var(--text-muted)'
  };
  const borderColor = error ? 'var(--status-critical)' : focus ? 'var(--accent)' : 'var(--line-soft)';
  const skins = {
    box: {
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-sm)',
      padding: '12px 38px 12px 14px',
      background: 'var(--surface-raised)',
      boxShadow: focus ? 'var(--shadow-focus)' : 'none'
    },
    line: {
      border: 'none',
      borderBottom: `1.5px solid ${borderColor}`,
      borderRadius: 0,
      padding: '8px 30px 8px 2px',
      background: 'transparent'
    }
  };
  const field = {
    appearance: 'none',
    WebkitAppearance: 'none',
    font: 'var(--type-body-m)',
    color: 'var(--text-strong)',
    width: '100%',
    outline: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'border-color var(--dur-fast) var(--ease-standard)',
    ...skins[variant]
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      ...wrap,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: labelStyle
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    defaultValue: defaultValue,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: field
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), options ? options.map(o => {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  }) : children), /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text-muted)",
    strokeWidth: "1.6",
    style: {
      position: 'absolute',
      right: variant === 'box' ? 14 : 4,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 9l6 6 6-6"
  }))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: error ? 'var(--status-critical)' : 'var(--text-faint)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/DetailScreen.jsx
try { (() => {
/* Auten website — Empreendimento detail. Exposes window.AutenKit.DetailScreen */
(function () {
  const {
    Button,
    Input,
    Select,
    Checkbox,
    Badge,
    Stat
  } = window.AutenDesignSystem_ff4469;
  const gallery = ['../../assets/imagery/architecture-concrete.jpg', '../../assets/imagery/interior-terracotta-lounge.jpg', '../../assets/imagery/lifestyle-wine.png'];
  function DetailScreen({
    id,
    onNav
  }) {
    const all = window.AutenKit.data.developments;
    const dev = all.find(d => d.id === id) || all[0];
    const [sent, setSent] = React.useState(false);
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
      style: {
        position: 'relative',
        height: '64vh',
        minHeight: '460px',
        display: 'flex',
        alignItems: 'flex-end',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        backgroundImage: `url(${dev.image})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(180deg, rgba(38,38,44,0.30) 0%, rgba(38,38,44,0.18) 45%, rgba(38,38,44,0.86) 100%)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        padding: '0 48px 56px',
        maxWidth: 'var(--container-wide)',
        margin: '0 auto',
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => onNav('listing'),
      style: {
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        font: 'var(--type-caption)',
        letterSpacing: 'var(--tracking-wide)',
        textTransform: 'uppercase',
        color: 'rgba(245,243,240,0.8)',
        marginBottom: '20px',
        padding: 0
      }
    }, "\u2190 Empreendimentos"), /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: '14px'
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: dev.statusTone,
      variant: "solid"
    }, dev.status)), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--type-caption)',
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        color: 'var(--auten-paper)',
        marginBottom: '10px'
      }
    }, dev.location), /*#__PURE__*/React.createElement("h1", {
      className: "auten-display",
      style: {
        margin: 0,
        font: 'var(--type-display-xl)',
        color: 'var(--auten-paper)'
      }
    }, dev.name), /*#__PURE__*/React.createElement("p", {
      className: "auten-display",
      style: {
        margin: '12px 0 0',
        font: 'var(--type-display-s)',
        fontStyle: 'italic',
        color: 'var(--auten-terracotta-soft)'
      }
    }, dev.tagline))), /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--surface-card)',
        borderBottom: '1px solid var(--line-hairline)',
        padding: '40px 48px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '32px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: '56px',
        flexWrap: 'wrap'
      }
    }, dev.specs.map((s, i) => /*#__PURE__*/React.createElement(Stat, {
      key: i,
      value: s.value,
      label: s.label
    })), /*#__PURE__*/React.createElement(Stat, {
      value: dev.price.replace('A partir de ', ''),
      suffix: dev.price.includes('partir') ? '+' : '',
      label: "Valores"
    })), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      onClick: () => document.getElementById('lead-form').scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      })
    }, "Tenho interesse"))), /*#__PURE__*/React.createElement("section", {
      style: {
        maxWidth: 'var(--container-wide)',
        margin: '0 auto',
        padding: '88px 48px 40px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '28px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "auten-rule"
    }), /*#__PURE__*/React.createElement("span", {
      className: "auten-eyebrow"
    }, "Galeria")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '2fr 1fr',
        gap: '16px',
        height: '460px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        backgroundImage: `url(${gallery[0]})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        borderRadius: 'var(--radius-md)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateRows: '1fr 1fr',
        gap: '16px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        backgroundImage: `url(${gallery[1]})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        borderRadius: 'var(--radius-md)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        backgroundImage: `url(${gallery[2]})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        borderRadius: 'var(--radius-md)'
      }
    })))), /*#__PURE__*/React.createElement("section", {
      id: "lead-form",
      style: {
        background: 'var(--surface-dark)',
        color: 'var(--auten-paper)',
        padding: '96px 48px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: '960px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '64px',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
      className: "auten-eyebrow"
    }, "Central de vendas"), /*#__PURE__*/React.createElement("h2", {
      className: "auten-display",
      style: {
        margin: '18px 0 16px',
        font: 'var(--type-display-m)',
        color: 'var(--auten-paper)'
      }
    }, "Agende uma visita ao ", dev.name), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        font: 'var(--type-body-m)',
        color: 'rgba(245,243,240,0.74)'
      }
    }, "Um de nossos especialistas entrar\xE1 em contato para apresentar as plantas, condi\xE7\xF5es e disponibilidade de unidades.")), /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--surface-raised)',
        borderRadius: 'var(--radius-md)',
        padding: '32px',
        boxShadow: 'var(--shadow-lg)'
      }
    }, sent ? /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        padding: '28px 0'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--type-display-s)',
        color: 'var(--text-strong)',
        fontFamily: 'var(--font-display)'
      }
    }, "Obrigado."), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-body-s)',
        color: 'var(--text-muted)',
        marginTop: '8px'
      }
    }, "Recebemos seu interesse no ", dev.name, ".")) : /*#__PURE__*/React.createElement("form", {
      onSubmit: e => {
        e.preventDefault();
        setSent(true);
      },
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '20px'
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Nome",
      placeholder: "Seu nome completo",
      variant: "line"
    }), /*#__PURE__*/React.createElement(Input, {
      label: "E-mail",
      type: "email",
      placeholder: "voce@email.com",
      variant: "line"
    }), /*#__PURE__*/React.createElement(Select, {
      label: "Dormit\xF3rios de interesse",
      variant: "line",
      options: ['2 suítes', '3 suítes', '4 suítes', 'Cobertura'],
      placeholder: "Selecione",
      defaultValue: ""
    }), /*#__PURE__*/React.createElement(Checkbox, {
      label: "Aceito receber contato e novidades da Auten",
      defaultChecked: true
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      type: "submit",
      fullWidth: true
    }, "Agendar visita"))))));
  }
  window.AutenKit = window.AutenKit || {};
  window.AutenKit.DetailScreen = DetailScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/DetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ExtraScreens.jsx
try { (() => {
/* Auten website — About + Contact. Exposes window.AutenKit.AboutScreen / ContactScreen */
(function () {
  const {
    Button,
    Input,
    Select,
    Checkbox,
    Stat
  } = window.AutenDesignSystem_ff4469;
  const values = [['Autenticidade', 'Ligados às tendências, fiéis à nossa essência.'], ['Sofisticação', 'O extraordinário cuidado com cada detalhe.'], ['Exclusividade', 'Endereços e projetos que poucos alcançam.'], ['Confiança', 'Entregas no prazo, do primeiro traço à chave.']];
  function AboutScreen({
    onNav
  }) {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
      style: {
        position: 'relative',
        height: '52vh',
        minHeight: '380px',
        display: 'flex',
        alignItems: 'flex-end',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        backgroundImage: 'url(../../assets/imagery/business-handshake.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(180deg, rgba(38,38,44,0.30), rgba(38,38,44,0.86))'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        padding: '0 48px 52px',
        maxWidth: 'var(--container-wide)',
        margin: '0 auto',
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-eyebrow)',
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        color: 'var(--auten-paper)'
      }
    }, "A Auten"), /*#__PURE__*/React.createElement("h1", {
      className: "auten-display",
      style: {
        margin: '14px 0 0',
        font: 'var(--type-display-l)',
        color: 'var(--auten-paper)',
        maxWidth: '18ch'
      }
    }, "Constru\xEDmos al\xE9m do espa\xE7o"))), /*#__PURE__*/React.createElement("section", {
      style: {
        maxWidth: '900px',
        margin: '0 auto',
        padding: '96px 48px',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("p", {
      className: "auten-display",
      style: {
        margin: 0,
        font: 'var(--type-display-m)',
        color: 'var(--text-strong)',
        lineHeight: 1.3
      }
    }, "Entendemos que cada linha do horizonte n\xE3o \xE9 apenas um convite ao infinito, mas um ", /*#__PURE__*/React.createElement("em", {
      style: {
        color: 'var(--text-accent)'
      }
    }, "desafio ao comum"), ".")), /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--surface-card)',
        padding: '90px 48px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '40px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "auten-rule"
    }), /*#__PURE__*/React.createElement("span", {
      className: "auten-eyebrow"
    }, "Nossos valores")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '32px'
      }
    }, values.map(([t, d]) => /*#__PURE__*/React.createElement("div", {
      key: t,
      style: {
        paddingTop: '20px',
        borderTop: '2px solid var(--auten-terracotta)'
      }
    }, /*#__PURE__*/React.createElement("h3", {
      style: {
        margin: '0 0 10px',
        font: 'var(--type-display-s)',
        fontFamily: 'var(--font-display)',
        color: 'var(--text-strong)'
      }
    }, t), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        font: 'var(--type-body-s)',
        color: 'var(--text-muted)'
      }
    }, d)))))), /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--surface-dark)',
        color: 'var(--auten-paper)',
        padding: '80px 48px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '40px'
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      value: "18",
      suffix: "+",
      label: "Anos de mercado",
      tone: "dark"
    }), /*#__PURE__*/React.createElement(Stat, {
      value: "2.400",
      label: "Unidades entregues",
      tone: "dark"
    }), /*#__PURE__*/React.createElement(Stat, {
      value: "12",
      label: "Bairros nobres",
      tone: "dark"
    }), /*#__PURE__*/React.createElement(Stat, {
      value: "100%",
      label: "No prazo",
      tone: "dark"
    }))));
  }
  function ContactScreen() {
    const [sent, setSent] = React.useState(false);
    return /*#__PURE__*/React.createElement("section", {
      style: {
        padding: '80px 48px 110px',
        maxWidth: 'var(--container-max)',
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '72px',
        alignItems: 'start'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '16px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "auten-rule"
    }), /*#__PURE__*/React.createElement("span", {
      className: "auten-eyebrow"
    }, "Contato")), /*#__PURE__*/React.createElement("h1", {
      className: "auten-display",
      style: {
        margin: 0,
        font: 'var(--type-display-l)'
      }
    }, "Vamos conversar"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '20px 0 36px',
        font: 'var(--type-body-l)',
        color: 'var(--text-muted)',
        maxWidth: '40ch'
      }
    }, "Nossa central de vendas est\xE1 pronta para ajudar voc\xEA a encontrar o endere\xE7o da sua pr\xF3xima hist\xF3ria."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '20px'
      }
    }, [['Central de vendas', '+55 11 4000-0000'], ['E-mail', 'vendas@auten.com.br'], ['Showroom', 'Rua dos Jardins, 1000 · São Paulo']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
      key: k,
      style: {
        borderTop: '1px solid var(--line-hairline)',
        paddingTop: '14px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--type-eyebrow)',
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        color: 'var(--text-faint)',
        marginBottom: '4px'
      }
    }, k), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--type-heading-s)',
        color: 'var(--text-strong)'
      }
    }, v))))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--surface-card)',
        borderRadius: 'var(--radius-md)',
        padding: '36px',
        boxShadow: 'var(--ring-card)'
      }
    }, sent ? /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        padding: '40px 0'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--type-display-s)',
        fontFamily: 'var(--font-display)',
        color: 'var(--text-strong)'
      }
    }, "Mensagem enviada."), /*#__PURE__*/React.createElement("p", {
      style: {
        font: 'var(--type-body-s)',
        color: 'var(--text-muted)',
        marginTop: '8px'
      }
    }, "Retornaremos em breve. Obrigado pelo interesse.")) : /*#__PURE__*/React.createElement("form", {
      onSubmit: e => {
        e.preventDefault();
        setSent(true);
      },
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '22px'
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Nome",
      placeholder: "Seu nome completo"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '20px'
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "E-mail",
      type: "email",
      placeholder: "voce@email.com"
    }), /*#__PURE__*/React.createElement(Input, {
      label: "Telefone",
      placeholder: "(11) 90000-0000"
    })), /*#__PURE__*/React.createElement(Select, {
      label: "Empreendimento de interesse",
      options: ['Auten Horizonte', 'Auten Vértice', 'Auten Reserva', 'Auten Cobre'],
      placeholder: "Selecione",
      defaultValue: ""
    }), /*#__PURE__*/React.createElement(Checkbox, {
      label: "Aceito receber contato e novidades da Auten",
      defaultChecked: true
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      type: "submit",
      fullWidth: true
    }, "Enviar mensagem")))));
  }
  window.AutenKit = window.AutenKit || {};
  window.AutenKit.AboutScreen = AboutScreen;
  window.AutenKit.ContactScreen = ContactScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ExtraScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
/* Auten website — shared footer. Exposes window.AutenKit.Footer */
(function () {
  function Col({
    title,
    items
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '14px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-eyebrow)',
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        color: 'rgba(245,243,240,0.5)'
      }
    }, title), items.map(i => /*#__PURE__*/React.createElement("a", {
      key: i,
      href: "#",
      onClick: e => e.preventDefault(),
      style: {
        font: 'var(--type-body-s)',
        color: 'rgba(245,243,240,0.82)'
      }
    }, i)));
  }
  function Footer({
    onNav
  }) {
    return /*#__PURE__*/React.createElement("footer", {
      style: {
        background: 'var(--surface-dark-deep)',
        color: 'var(--auten-paper)',
        padding: '72px 48px 40px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-wide)',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: '1.6fr 1fr 1fr 1fr',
        gap: '48px',
        paddingBottom: '56px',
        borderBottom: '1px solid var(--line-on-dark)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '20px',
        maxWidth: '320px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/logo/auten-mark.svg",
      width: "36",
      height: "36",
      alt: "Auten"
    }), /*#__PURE__*/React.createElement("span", {
      className: "auten-wordmark",
      style: {
        fontSize: '22px',
        color: 'var(--auten-paper)'
      }
    }, "Auten")), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        font: 'var(--type-body-s)',
        color: 'rgba(245,243,240,0.7)'
      }
    }, "Incorporadora de empreendimentos residenciais de alto padr\xE3o. Onde o extraordin\xE1rio \xE9 a norma.")), /*#__PURE__*/React.createElement(Col, {
      title: "Empreendimentos",
      items: ['Lançamentos', 'Em obras', 'Prontos para morar', 'Coberturas']
    }), /*#__PURE__*/React.createElement(Col, {
      title: "A Auten",
      items: ['Quem somos', 'Nosso DNA', 'Trabalhe conosco', 'Imprensa']
    }), /*#__PURE__*/React.createElement(Col, {
      title: "Contato",
      items: ['Central de vendas', 'WhatsApp', 'Instagram', 'LinkedIn']
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-wide)',
        margin: '0 auto',
        paddingTop: '28px',
        display: 'flex',
        justifyContent: 'space-between',
        font: 'var(--type-caption)',
        color: 'rgba(245,243,240,0.5)'
      }
    }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Auten Incorporadora \xB7 CRECI 00000-J"), /*#__PURE__*/React.createElement("span", {
      style: {
        letterSpacing: 'var(--tracking-wide)'
      }
    }, "Voc\xEA merece chegar l\xE1")));
  }
  window.AutenKit = window.AutenKit || {};
  window.AutenKit.Footer = Footer;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
/* Auten website — shared header. Exposes window.AutenKit.Header */
(function () {
  const {
    IconButton
  } = window.AutenDesignSystem_ff4469;
  function Header({
    tone = 'light',
    active = 'home',
    onNav,
    float = false
  }) {
    const onDark = tone === 'dark';
    const [hover, setHover] = React.useState(null);
    const ink = onDark ? 'var(--auten-paper)' : 'var(--text-strong)';
    const muted = onDark ? 'rgba(245,243,240,0.74)' : 'var(--text-muted)';
    const nav = [{
      id: 'listing',
      label: 'Empreendimentos'
    }, {
      id: 'about',
      label: 'A Auten'
    }, {
      id: 'contact',
      label: 'Contato'
    }];
    return /*#__PURE__*/React.createElement("header", {
      style: {
        position: float ? 'absolute' : 'sticky',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 20,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '20px 48px',
        background: float ? 'transparent' : onDark ? 'var(--surface-dark)' : 'var(--surface-page)',
        borderBottom: `1px solid ${float ? 'transparent' : onDark ? 'var(--line-on-dark)' : 'var(--line-hairline)'}`
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => onNav && onNav('home'),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: 0
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: onDark ? '../../assets/logo/auten-mark.svg' : '../../assets/logo/auten-monogram.svg',
      width: "34",
      height: "34",
      alt: "Auten"
    }), /*#__PURE__*/React.createElement("span", {
      className: "auten-wordmark",
      style: {
        fontSize: '20px',
        color: ink
      }
    }, "Auten")), /*#__PURE__*/React.createElement("nav", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '38px'
      }
    }, nav.map(n => /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => onNav && onNav(n.id),
      onMouseEnter: () => setHover(n.id),
      onMouseLeave: () => setHover(null),
      style: {
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '4px 0',
        font: 'var(--type-label)',
        letterSpacing: 'var(--tracking-wide)',
        color: active === n.id || hover === n.id ? onDark ? 'var(--auten-paper)' : 'var(--text-accent)' : muted,
        borderBottom: active === n.id ? '1px solid var(--auten-terracotta)' : '1px solid transparent',
        transition: 'color var(--dur-fast) var(--ease-standard)'
      }
    }, n.label)), /*#__PURE__*/React.createElement("button", {
      onClick: () => onNav && onNav('contact'),
      style: {
        font: 'var(--type-eyebrow)',
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        fontWeight: 'var(--weight-semibold)',
        padding: '11px 22px',
        borderRadius: 'var(--radius-sm)',
        cursor: 'pointer',
        background: 'var(--accent)',
        color: 'var(--accent-contrast)',
        border: 'none'
      }
    }, "Agendar visita")));
  }
  window.AutenKit = window.AutenKit || {};
  window.AutenKit.Header = Header;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Auten website — Home screen. Exposes window.AutenKit.HomeScreen */
(function () {
  const {
    Button,
    Stat,
    PropertyCard,
    Badge
  } = window.AutenDesignSystem_ff4469;
  function Hero({
    onNav
  }) {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        position: 'relative',
        minHeight: '78vh',
        display: 'flex',
        alignItems: 'flex-end',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        backgroundImage: 'url(../../assets/imagery/cover-architecture.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(180deg, rgba(38,38,44,0.55) 0%, rgba(38,38,44,0.25) 40%, rgba(38,38,44,0.85) 100%)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        padding: '0 48px 72px',
        maxWidth: '900px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '22px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 40,
        height: 1,
        background: 'var(--auten-terracotta)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-eyebrow)',
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        color: 'var(--auten-paper)'
      }
    }, "Incorporadora \xB7 Alto padr\xE3o")), /*#__PURE__*/React.createElement("h1", {
      className: "auten-display",
      style: {
        margin: 0,
        font: 'var(--type-display-xl)',
        color: 'var(--auten-paper)',
        maxWidth: '14ch'
      }
    }, "O extraordin\xE1rio \xE9 a ", /*#__PURE__*/React.createElement("em", {
      style: {
        color: 'var(--auten-terracotta-soft)'
      }
    }, "norma")), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '24px 0 34px',
        font: 'var(--type-body-l)',
        color: 'rgba(245,243,240,0.86)',
        maxWidth: '46ch'
      }
    }, "Empreendimentos que s\xE3o mais do que um lugar \u2014 um palco para a sua grandeza pessoal, nos endere\xE7os mais desejados de S\xE3o Paulo."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: '14px'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      onClick: () => onNav('listing')
    }, "Conhecer empreendimentos"), /*#__PURE__*/React.createElement(Button, {
      variant: "onDark",
      size: "lg",
      onClick: () => onNav('contact')
    }, "Agendar visita"))));
  }
  function Featured({
    onOpen
  }) {
    const items = window.AutenKit.data.developments.slice(0, 4);
    return /*#__PURE__*/React.createElement("section", {
      style: {
        padding: '96px 48px',
        maxWidth: 'var(--container-wide)',
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'space-between',
        marginBottom: '44px'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '14px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "auten-rule"
    }), /*#__PURE__*/React.createElement("span", {
      className: "auten-eyebrow"
    }, "Portf\xF3lio")), /*#__PURE__*/React.createElement("h2", {
      className: "auten-display",
      style: {
        margin: 0,
        font: 'var(--type-display-l)'
      }
    }, "Empreendimentos em destaque")), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => onOpen()
    }, "Ver todos \u2192")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '24px'
      }
    }, items.map(d => /*#__PURE__*/React.createElement(PropertyCard, _extends({
      key: d.id
    }, d, {
      onClick: () => onOpen(d.id)
    })))));
  }
  function Manifesto() {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--surface-card)',
        padding: '110px 48px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: '980px',
        margin: '0 auto',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "auten-eyebrow"
    }, "DNA Auten"), /*#__PURE__*/React.createElement("p", {
      className: "auten-display",
      style: {
        margin: '24px 0 0',
        font: 'var(--type-display-m)',
        color: 'var(--text-strong)',
        lineHeight: 1.28,
        textWrap: 'balance'
      }
    }, "Na Auten, cada detalhe \xE9 um eco da sua determina\xE7\xE3o, cada design uma celebra\xE7\xE3o da sua ", /*#__PURE__*/React.createElement("em", {
      style: {
        color: 'var(--text-accent)'
      }
    }, "jornada \xFAnica"), ".")));
  }
  function Stats() {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--surface-dark)',
        color: 'var(--auten-paper)',
        padding: '88px 48px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '40px'
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      value: "18",
      suffix: "+",
      label: "Anos de mercado",
      tone: "dark"
    }), /*#__PURE__*/React.createElement(Stat, {
      value: "2.400",
      label: "Unidades entregues",
      tone: "dark"
    }), /*#__PURE__*/React.createElement(Stat, {
      value: "12",
      label: "Bairros nobres",
      tone: "dark"
    }), /*#__PURE__*/React.createElement(Stat, {
      value: "100%",
      label: "No prazo",
      tone: "dark"
    })));
  }
  function CTA({
    onNav
  }) {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        position: 'relative',
        padding: '120px 48px',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        backgroundImage: 'url(../../assets/imagery/interior-terracotta-lounge.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'rgba(38,38,44,0.66)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        maxWidth: '720px',
        margin: '0 auto',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      className: "auten-display",
      style: {
        margin: 0,
        font: 'var(--type-display-l)',
        color: 'var(--auten-paper)'
      }
    }, "Onde voc\xEA j\xE1 chegou merece um endere\xE7o \xE0 altura"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '20px 0 32px',
        font: 'var(--type-body-l)',
        color: 'rgba(245,243,240,0.85)'
      }
    }, "Converse com nossa central de vendas e descubra a unidade perfeita para a sua hist\xF3ria."), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      onClick: () => onNav('contact')
    }, "Falar com um especialista")));
  }
  function HomeScreen({
    onNav,
    onOpen
  }) {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Hero, {
      onNav: onNav
    }), /*#__PURE__*/React.createElement(Featured, {
      onOpen: onOpen
    }), /*#__PURE__*/React.createElement(Manifesto, null), /*#__PURE__*/React.createElement(Stats, null), /*#__PURE__*/React.createElement(CTA, {
      onNav: onNav
    }));
  }
  window.AutenKit = window.AutenKit || {};
  window.AutenKit.HomeScreen = HomeScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ListingScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Auten website — Empreendimentos listing. Exposes window.AutenKit.ListingScreen */
(function () {
  const {
    PropertyCard,
    Select,
    Badge
  } = window.AutenDesignSystem_ff4469;
  function ListingScreen({
    onOpen
  }) {
    const all = window.AutenKit.data.developments;
    const [filter, setFilter] = React.useState('Todos');
    const statuses = ['Todos', 'Lançamento', 'Em obras', 'Pronto para morar'];
    const shown = filter === 'Todos' ? all : all.filter(d => d.status === filter);
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--surface-dark)',
        color: 'var(--auten-paper)',
        padding: '80px 48px 72px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-wide)',
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '16px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 40,
        height: 1,
        background: 'var(--auten-terracotta)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-eyebrow)',
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        color: 'var(--auten-paper)'
      }
    }, "Portf\xF3lio")), /*#__PURE__*/React.createElement("h1", {
      className: "auten-display",
      style: {
        margin: 0,
        font: 'var(--type-display-l)',
        color: 'var(--auten-paper)'
      }
    }, "Empreendimentos"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '18px 0 0',
        font: 'var(--type-body-l)',
        color: 'rgba(245,243,240,0.78)',
        maxWidth: '52ch'
      }
    }, "Endere\xE7os selecionados nos bairros mais desejados de S\xE3o Paulo. Cada projeto, uma celebra\xE7\xE3o da grandeza pessoal."))), /*#__PURE__*/React.createElement("section", {
      style: {
        maxWidth: 'var(--container-wide)',
        margin: '0 auto',
        padding: '40px 48px 96px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '32px',
        borderBottom: '1px solid var(--line-hairline)',
        paddingBottom: '20px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: '10px',
        flexWrap: 'wrap'
      }
    }, statuses.map(s => /*#__PURE__*/React.createElement("button", {
      key: s,
      onClick: () => setFilter(s),
      style: {
        font: 'var(--type-label)',
        letterSpacing: 'var(--tracking-wide)',
        cursor: 'pointer',
        padding: '9px 18px',
        borderRadius: 'var(--radius-pill)',
        border: `1px solid ${filter === s ? 'var(--auten-terracotta)' : 'var(--line-soft)'}`,
        background: filter === s ? 'var(--auten-terracotta)' : 'transparent',
        color: filter === s ? 'var(--accent-contrast)' : 'var(--text-muted)',
        transition: 'all var(--dur-fast) var(--ease-standard)'
      }
    }, s))), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-caption)',
        letterSpacing: 'var(--tracking-wide)',
        textTransform: 'uppercase',
        color: 'var(--text-faint)'
      }
    }, shown.length, " empreendimentos")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '28px'
      }
    }, shown.map(d => /*#__PURE__*/React.createElement(PropertyCard, _extends({
      key: d.id
    }, d, {
      onClick: () => onOpen(d.id)
    }))))));
  }
  window.AutenKit = window.AutenKit || {};
  window.AutenKit.ListingScreen = ListingScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ListingScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
/* Auten website — shared mock data. Exposes window.AutenKit.data */
(function () {
  const developments = [{
    id: 'horizonte',
    name: 'Auten Horizonte',
    location: 'Jardins · São Paulo',
    status: 'Lançamento',
    statusTone: 'accent',
    price: 'A partir de R$ 2,4 mi',
    image: '../../assets/imagery/cover-architecture.png',
    tagline: 'Cada linha do horizonte, um convite ao infinito',
    specs: [{
      value: '142–210 m²',
      label: 'Privativos'
    }, {
      value: '3 e 4 suítes',
      label: 'Dormitórios'
    }, {
      value: '2–4 vagas',
      label: 'Garagem'
    }]
  }, {
    id: 'vertice',
    name: 'Auten Vértice',
    location: 'Vila Nova Conceição · SP',
    status: 'Em obras',
    statusTone: 'slate',
    price: 'A partir de R$ 3,1 mi',
    image: '../../assets/imagery/architecture-concrete.jpg',
    tagline: 'Arquitetura que define novos padrões',
    specs: [{
      value: '188 m²',
      label: 'Privativos'
    }, {
      value: '4 suítes',
      label: 'Dormitórios'
    }, {
      value: '3 vagas',
      label: 'Garagem'
    }]
  }, {
    id: 'reserva',
    name: 'Auten Reserva',
    location: 'Higienópolis · São Paulo',
    status: 'Pronto para morar',
    statusTone: 'positive',
    price: 'R$ 4,8 mi',
    image: '../../assets/imagery/interior-terracotta-lounge.jpg',
    tagline: 'Um palco para a grandeza pessoal',
    specs: [{
      value: '256 m²',
      label: 'Privativos'
    }, {
      value: '4 suítes',
      label: 'Dormitórios'
    }, {
      value: '4 vagas',
      label: 'Garagem'
    }]
  }, {
    id: 'cobre',
    name: 'Auten Cobre',
    location: 'Itaim Bibi · São Paulo',
    status: 'Lançamento',
    statusTone: 'accent',
    price: 'A partir de R$ 1,9 mi',
    image: '../../assets/imagery/palette-textures.jpg',
    tagline: 'Detalhe que vira assinatura',
    specs: [{
      value: '96–138 m²',
      label: 'Privativos'
    }, {
      value: '2 e 3 suítes',
      label: 'Dormitórios'
    }, {
      value: '2 vagas',
      label: 'Garagem'
    }]
  }];
  window.AutenKit = window.AutenKit || {};
  window.AutenKit.data = {
    developments
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Card = __ds_scope.Card;

__ds_ns.PropertyCard = __ds_scope.PropertyCard;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

})();
