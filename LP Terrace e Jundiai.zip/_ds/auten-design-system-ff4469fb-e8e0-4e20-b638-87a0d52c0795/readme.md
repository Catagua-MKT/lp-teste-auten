# Auten Design System

A design system for **Auten Incorporadora** — a São Paulo real‑estate developer
("incorporadora") of high‑end residential buildings. The system encodes the
visual and verbal identity from the **Auten rebrand** ("Rebranding Auten V02",
by the agency Atsuki) into tokens, components, foundation specimens and a
working website UI kit.

> **Positioning.** Luxury, architectural, restrained. The brand sells not just
> apartments but *arrival* — "onde você já chegou". Archetypes: **Herói** (Hero)
> + **Governante** (Ruler). The promise: *"o extraordinário é a norma."*

## Sources

- `uploads/Rebranding Auten V02.pdf` — the brandbook (54 pages). The single
  source of truth for this system. Page renders extracted to `pdf_pages/` for
  reference (palette, typography specimens, moodboard, logo mockups, social grid).
- No codebase or Figma file was provided. Everything here is derived from the
  brandbook. Where the brandbook left a gap (icon system, web components), a
  sensible, on‑brand default was chosen and is **flagged** below.

---

## CONTENT FUNDAMENTALS — how Auten writes

The voice is **aspirational, literary and confident**, in **Brazilian
Portuguese**. It elevates the everyday into the extraordinary.

- **Address: "você".** The brand speaks directly and warmly to the reader —
  *"Você merece"*, *"onde você já chegou"*, *"a sua jornada única"*. First person
  plural ("nós/Na Auten") is used for the brand itself: *"Na Auten, entendemos…"*.
- **Register: elevated, poetic, but never ornate to the point of vague.** Short
  declarative manifestos, often built on contrast: *"Não é apenas sobre o que
  você pode alcançar, mas sobre onde você já chegou."*
- **Recurring motifs in copy:** horizonte/infinito, palco, grandeza pessoal,
  jornada, detalhe, padrões, além do espaço. Lean on these.
- **Casing:** Sentence case for headlines and body. **Letterspaced UPPERCASE**
  only for eyebrows, labels and the AUTEN wordmark — never for long text.
- **Sentence length:** headlines are tight (one breath). Body runs to a single
  idea per sentence with generous rhythm.
- **No emoji. No exclamation spam.** At most one exclamation; usually none. The
  tone is calm authority, not hype.
- **Numbers** earn their place — credibility figures only (anos de mercado,
  unidades entregues). Avoid stat‑slop.

Example headlines (brandbook):
> "O extraordinário é a norma."
> "Cada espaço que criamos é mais do que um lugar; é um palco para a grandeza pessoal."
> "Convidamos você a quebrar barreiras, a definir novos padrões e a viver além do espaço."

CTA copy is plain and active: *Agendar visita · Conhecer empreendimentos ·
Falar com um especialista · Tenho interesse.*

---

## VISUAL FOUNDATIONS

**Overall vibe.** Architectural minimalism with warmth. Vast negative space,
high‑contrast serif display set large, a single warm accent (terracotta/cobre)
used sparingly against slate and warm greys. Editorial, gallery‑like, quiet.

### Color
- **One accent only: terracotta / cobre `#B15732`** ("Impacto"). It appears as
  small punctuation — a CTA, a rule, an italic word, a status pill — never as a
  large flood except over a darkened photo.
- **Slate / graphite `#3D3D47`–`#33333B`** ("Elegância") carries dark surfaces
  and primary text. Deepest ink `#26262C`.
- **Warm light neutrals**: greige `#B0ABB0` ("Autêntico"), mist `#D2D2D2`
  ("Exclusividade"), and the page canvas — bone `#ECEAE6` / paper `#F5F3F0`.
- The palette is **warm‑neutral with a cool slate counterpoint**. No bright
  colour, no gradients-as-decoration. Gradients exist only as **photo
  protection scrims** (dark, bottom‑weighted) so text reads over imagery.

### Typography
- **Display — Essonnes** (a licensed high‑contrast Didone), used for titles,
  headlines and **editorial italics** (the italic is a signature — *"razão de
  existir"*, *"Teoria Arquetípica"*). **Substituted in this system with
  Playfair Display** (Google Fonts), the closest free high‑contrast Didone —
  see Caveats.
- **Text — Gantari** (Google Fonts), a clean geometric‑humanist sans for body,
  UI, labels and letterspaced eyebrows. Also the basis of the **AUTEN
  wordmark** (semibold, ~0.32em tracking, uppercase).
- Display is set **large and tight** (`-0.01em`); eyebrows are **small and wide**
  (`0.22em`, uppercase). This contrast of scale + tracking is the core
  typographic move.

### Spacing & layout
- 4px base scale; **generous** section padding (96–128px vertical on web).
- Wide gutters (48px page margins), centred max‑widths, reading measure ~64ch.
- Composition favours asymmetry, thin hairline rules, and a short terracotta
  rule (`.auten-rule`, 48×1px) as a recurring divider beneath eyebrows.

### Surfaces, borders, radii, shadow
- **Architectural, mostly squared.** Radii are small: cards/buttons `4–6px`
  (the monogram tile is `6px`). Pills only for badges/filter chips.
- **Borders are hairlines** (`rgba(38,38,44,0.12–0.32)`); on dark, light
  hairlines. Cards on light lift with an **inset hairline ring** rather than a
  heavy shadow.
- **Shadows are low, warm and diffuse** — no glow, no coloured shadow. Elevation
  is used sparingly (hover lift on cards and the listing tile).

### Imagery
- **Warm, aspirational, cinematic.** Architecture (façades, concrete, light),
  affluent lifestyle (well‑dressed people, interiors), material close‑ups
  (copper, stone, fabric). Tones skew warm with controlled contrast; never
  neon, rarely pure B&W.
- Photos are framed full‑bleed in heroes with a **dark bottom protection
  gradient**, or gridded as tiles. People look aspirational and composed.

### Motion & states
- **Calm and confident.** Short fades and small translates (≤3px lift); standard
  easing `cubic-bezier(0.22,0.61,0.36,1)`; durations 140–420ms. **No bounce, no
  spring, no parallax theatrics.**
- **Hover:** accent lightens (`terracotta-soft`), neutrals gain a faint wash,
  cards lift + shadow, images scale ~1.04. **Press:** 1px downward nudge.
- **Focus:** 3px soft terracotta ring (`--focus-ring`).
- Respect `prefers-reduced-motion` (handled in `tokens/base.css`).

### Transparency & blur
- Used rarely — only photo scrims and (optionally) a translucent panel over
  imagery. The default header on dark heroes is **fully transparent**, not
  blurred glass.

---

## ICONOGRAPHY

The brandbook defines **no proprietary icon set** and uses **no emoji and no
unicode dingbats**. Its only "icon" is the **A‑peak monogram** (a stylized "A"
mountain/horizon mark) and **thin hairline rules**.

**Documented default (flagged substitution):** for UI glyphs (chevrons, arrows,
close, etc.) use **thin line icons at ~1.5–1.6px stroke**, matching the brand's
hairline language. The UI kit draws its few glyphs as inline SVG at
`stroke-width:1.6`, `currentColor`. For a fuller set, link **Lucide**
(https://unpkg.com/lucide@latest) — its 1.5px stroke and squared‑round terminals
sit comfortably with Gantari. **No filled/duotone icon styles.** **Never emoji.**

**Official logo — the AUTEN INCORPORADORA wordmark.** The primary brand
signature is the full wordmark lockup (the letters **AUTEN** above a small,
letterspaced **INCORPORADORA**), supplied by the client. Use it as a real image
asset — do **not** re‑typeset it from the Gantari font.

Logo assets live in `assets/logo/`:
- `auten-wordmark-slate.png` — official wordmark in slate `#3D3D47`, transparent
  background. Primary lockup for **light** surfaces (bone / paper).
- `auten-wordmark-white.png` — official wordmark in paper `#F5F3F0`, transparent
  background. For **dark** surfaces — slate/ink heroes, footers, the scrolled nav.
- `auten-wordmark-square.png` — wordmark centred on a white field, for avatars,
  favicons and social tiles.
- `auten-monogram.svg` / `auten-monogram-slate.svg` / `auten-mark.svg` — the
  A‑peak monogram, for compact or standalone marks where the full wordmark won't fit.

**Usage rules.** Keep clear space around the wordmark of at least the cap‑height
of "AUTEN". Only the two brand neutrals are allowed — **slate on light, paper
(white) on dark**; never place the slate version on a dark surface or photo (use
the white asset instead). Never stretch, rotate, recolour, outline or add shadow
to the lockup. Minimum legible height ≈ 18px for the full lockup; below that,
fall back to the A‑peak monogram.

> ✅ These are the **official** client‑supplied logo files (the earlier traced
> recreations have been replaced). The A‑peak monogram SVGs remain recreations
> pending an official vector.

---

## Index / manifest

**Root**
- `styles.css` — the single entry point consumers link (imports only).
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`,
  `fonts.css`, `base.css`.
- `assets/` — `logo/` (official AUTEN INCORPORADORA wordmark PNGs — slate / white
  / square — plus the A‑peak monogram SVGs), `imagery/` (brand photography
  extracted from the brandbook).
- `guidelines/cards/` — foundation specimen cards (Design System tab).
- `pdf_pages/` — reference page renders from the brandbook (not shipped intent).
- `SKILL.md` — Agent‑Skills entry point for downloading/using this system.

**Components** (`window.AutenDesignSystem_ff4469.*`)
- `components/core/` — **Button**, **IconButton**, **Badge**
- `components/forms/` — **Input**, **Select**, **Checkbox**
- `components/content/` — **Card**, **PropertyCard**, **Stat**

**UI kits**
- `ui_kits/website/` — Auten marketing website, interactive: home → portfolio →
  development detail → about → contact. Composes the components above.
  Entry: `ui_kits/website/index.html`.

**Starting points**
- `Button` (Core) · `PropertyCard` (Real Estate) · the website `index.html`.
